
# This is a list of musicians, music genre, track and track duration

Artist = "Neol Gallagher"
Genre = "Rock"
Track = "A Simple Game of Genius"
DurationInSeconds, seconds  = 438, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "Ed Sheeran"
Genre = "Pop"
Track = "The a Team"
DurationInSeconds, seconds = 256, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "David Bowie"
Genre = "Pop"
Track = "Absolute Beginners"
DurationInSeconds, seconds = 338, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "The Pretty Reckless"
Genre = "Rock"
Track = "Absolution"
DurationInSeconds, seconds = 274, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "Status Quo"
Genre = "Rock"
Track = "Accident Prone"
DurationInSeconds, seconds = 304, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "Motorhead"
Genre = "Heavy Metal"
Track = "Ace of Spades"
DurationInSeconds, seconds = 323, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

Artist = "Iron Maiden"
Genre = "Heavy Metal"
Track = "Aces High - Live"
DurationInSeconds, seconds = 278, "seconds"

print(Artist)
print(Genre)
print(Track)
print(DurationInSeconds, seconds)

"""From this point on I have changed to the single line format.
This makes the output more readable."""

Artist, Genre, Track, DurationInSeconds, seconds = "Goldfrapp", "Pop", "A&E", 199, "seconds"
# Genre = "Pop"
# Track = "A&E"
# DurationInSeconds, seconds = 199, "seconds"

print(Artist, Genre, Track, DurationInSeconds, seconds)
# print(Genre)
# print(Track)
# print(DurationInSeconds, seconds)

Artist, Genre, Track, DurationInSeconds, seconds = "Kid Rock", "Rock", "Abortion", 270, "seconds"
# Genre = "Rock"
# Track = "Abortion"
# DurationInSeconds, seconds = 270, "seconds"

print(Artist, Genre, Track, DurationInSeconds, seconds)
# print(Genre)
# print(Track)
# print(DurationInSeconds, seconds)

Artist, Genre, Track, DurationInSeconds, seconds = "Nirvana", "Grunge", "About a Girl", 171, "seconds"
# Genre = "Grunge"
# Track = "About a Girl"
# DurationInSeconds, seconds = 171, "seconds"

print(Artist, Genre, Track, DurationInSeconds, seconds)
# print(Genre)
# print(Track)
# print(DurationInSeconds, seconds)